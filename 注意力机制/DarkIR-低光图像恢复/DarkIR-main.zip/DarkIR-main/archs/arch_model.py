import torch  # PyTorch 核心库
import torch.nn as nn  # 神经网络模块（Conv2d、Module 等）
import torch.nn.init as init  # 初始化工具（此处未直接使用，可用于权重初始化）
import torch.nn.functional as F  # 函数式 API（此处未直接使用，例如 F.relu 等）

try:
    from .arch_util import LayerNorm2d  # 相对导入二维特征的层归一化（适用于包内引用）
except:
    from arch_util import LayerNorm2d  # 相对导入失败时使用绝对导入（脚本直跑时生效）


class SimpleGate(nn.Module):  # 简单门控：按通道一分为二并做逐元素乘法
    # 注意：输入通道 C 必须为偶数，否则 x.chunk(2, dim=1) 会报错
    # 形状约定：输入 [B, C, H, W]，输出 [B, C/2, H, W]
    def forward(self, x):  # x: [B, C, H, W]
        x1, x2 = x.chunk(2, dim=1)  # 沿通道维均分为两部分（各 C/2）
        return x1 * x2  # 逐元素乘法，融合两半通道信息（通道数变为 C/2）

class Adapter(nn.Module):  # 可选的适配器模块（当前在 EBlock/DBlock 中未使用）
    
    def __init__(self, c, ffn_channel = None):  # c: 输入通道，ffn_channel: 展开通道数
        super().__init__()
        if ffn_channel:
            ffn_channel = 2  # 若传入（真值），则固定为 2（注意：这与一般“设置为指定值”的直觉不同）
        else:
            ffn_channel = c  # 否则与输入通道一致
        self.conv1 = nn.Conv2d(in_channels=c, out_channels=ffn_channel, kernel_size=1, padding=0, stride=1, groups=1, bias=True)  # 1x1 卷积做通道变换
        self.conv2 = nn.Conv2d(in_channels=ffn_channel, out_channels=c, kernel_size=1, padding=0, stride=1, groups=1, bias=True)  # 1x1 投影回原通道
        self.depthwise = nn.Conv2d(in_channels=c, out_channels=ffn_channel, kernel_size=3, padding=1, stride=1, groups=c, bias=True, dilation=1)  # 3x3 深度可分离卷积（groups=c）

    def forward(self, input):  # input: [B, C, H, W]
        
        x = self.conv1(input) + self.depthwise(input)  # 点卷积（全通道交互）与深度卷积（空间建模）的融合
        x = self.conv2(x)  # 投影回 C 通道
        
        return x  # 输出适配后的特征

class FreMLP(nn.Module):  # 频域 MLP 调制模块（对谱幅值进行轻量非线性变换）
    
    def __init__(self, nc, expand = 2):  # nc: 通道数，expand: 幅值 MLP 的扩展倍数
        super(FreMLP, self).__init__()
        self.process1 = nn.Sequential(
            nn.Conv2d(nc, expand * nc, 1, 1, 0),  # 1x1 扩展通道
            nn.LeakyReLU(0.1, inplace=True),  # 激活
            nn.Conv2d(expand * nc, nc, 1, 1, 0))  # 1x1 投影回原通道

    def forward(self, x):  # x: [B, C, H, W]
        _, _, H, W = x.shape  # 记录空间尺寸用于反变换
        x_freq = torch.fft.rfft2(x, norm='backward')  # 实数二维 FFT，得到复数谱（W 方向为 N//2+1）
        mag = torch.abs(x_freq)  # 幅值
        pha = torch.angle(x_freq)  # 相位
        mag = self.process1(mag)  # 对幅值做轻量 MLP 调制（逐像素逐通道）
        real = mag * torch.cos(pha)  # 复原实部
        imag = mag * torch.sin(pha)  # 复原虚部
        x_out = torch.complex(real, imag)  # 复数张量
        x_out = torch.fft.irfft2(x_out, s=(H, W), norm='backward')  # 逆 FFT 回到空间域（尺寸复原为 HxW）
        return x_out  # [B, C, H, W]

class Branch(nn.Module):  # 单分支：在扩展通道上做深度可分离空洞卷积
    '''
    Branch that lasts lonly the dilated convolutions
    '''
    def __init__(self, c, DW_Expand, dilation = 1):  # c: 基础通道数，DW_Expand: 扩展倍数，dilation: 空洞率
        super().__init__()
        self.dw_channel = DW_Expand * c  # 扩展后的通道数
        
        self.branch = nn.Sequential(
                       nn.Conv2d(
                           in_channels=self.dw_channel,
                           out_channels=self.dw_channel,
                           kernel_size=3,
                           padding=dilation,  # 保持尺寸不变：当 stride=1、kernel=3 时，padding=dilation
                           stride=1,
                           groups=self.dw_channel,  # 深度卷积：每个通道独立卷积
                           bias=True,
                           dilation = dilation  # 空洞率，>1 可扩大感受野
                       )
        )  # 3x3 深度空洞卷积（DW），不改变张量形状
    def forward(self, input):  # input: [B, DW_Expand*C, H, W]
        return self.branch(input)  # 输出与输入形状一致
    
class DBlock(nn.Module):  # 类 Dense 的块：多分支深度卷积 + FFN
    '''
    Change this block using Branch
    '''
    
    def __init__(self, c, DW_Expand=2, FFN_Expand=2, dilations = [1], extra_depth_wise = False):
        super().__init__()
        # 定义多分支
        self.dw_channel = DW_Expand * c  # 深度卷积的扩展通道数

        self.conv1 = nn.Conv2d(in_channels=c, out_channels=self.dw_channel, kernel_size=1, padding=0, stride=1, groups=1, bias=True, dilation = 1)  # 1x1 扩展到深度卷积空间（通道变为 DW_Expand*c）
        self.extra_conv = nn.Conv2d(self.dw_channel, self.dw_channel, kernel_size=3, padding=1, stride=1, groups=c, bias=True, dilation=1) if extra_depth_wise else nn.Identity() # 可选额外深度卷积
        self.branches = nn.ModuleList()
        for dilation in dilations:
            self.branches.append(Branch(self.dw_channel, DW_Expand = 1, dilation = dilation))  # 并行空洞分支
            
        assert len(dilations) == len(self.branches)  # 合法性检查
        self.dw_channel = DW_Expand * c  # 供后续 SCA 计算通道
        self.sca = nn.Sequential(
                       nn.AdaptiveAvgPool2d(1),  # 全局上下文
                       nn.Conv2d(in_channels=self.dw_channel // 2, out_channels=self.dw_channel // 2, kernel_size=1, padding=0, stride=1,
                       groups=1, bias=True, dilation = 1),  
        )  # 简单通道注意力（在 SimpleGate 之后的半通道上）
        self.sg1 = SimpleGate()  # 聚合分支后的门控（要求通道数可被 2 整除）
        self.sg2 = SimpleGate()  # FFN 内部的门控
        self.conv3 = nn.Conv2d(in_channels=self.dw_channel // 2, out_channels=c, kernel_size=1, padding=0, stride=1, groups=1, bias=True, dilation = 1)  # 门控后通道减半，再用 1x1 投影回 C
        ffn_channel = FFN_Expand * c  # FFN 扩展通道数
        self.conv4 = nn.Conv2d(in_channels=c, out_channels=ffn_channel, kernel_size=1, padding=0, stride=1, groups=1, bias=True)  # FFN 第一步：1x1 扩展通道到 2C（若 FFN_Expand=2）
        self.conv5 = nn.Conv2d(in_channels=ffn_channel // 2, out_channels=c, kernel_size=1, padding=0, stride=1, groups=1, bias=True)  # FFN 第三步：门控后通道减半，再 1x1 回到 C

        self.norm1 = LayerNorm2d(c)  # 分支前归一化
        self.norm2 = LayerNorm2d(c)  # FFN 前归一化

        self.gamma = nn.Parameter(torch.zeros((1, c, 1, 1)), requires_grad=True)  # FFN 残差缩放
        self.beta = nn.Parameter(torch.zeros((1, c, 1, 1)), requires_grad=True)  # 分支残差缩放


#        self.adapter = Adapter(c, ffn_channel=None)  # Optional adapter (disabled)
        
#        self.use_adapters = False  # Flag to enable adapters (unused)

#    def set_use_adapters(self, use_adapters):
#        self.use_adapters = use_adapters
        
    def forward(self, inp, adapter = None):  # inp: [B, C, H, W]

        y = inp  # 残差分支基线（与后续输出相加）
        x = self.norm1(inp)  # 归一化输入（稳定训练）
        # x = self.conv1(self.extra_conv(x))
        x = self.extra_conv(self.conv1(x))  # 通道扩展，并可选额外深度卷积
        z = 0  # 多分支累加器
        for branch in self.branches:
            z += branch(x)  # 各空洞分支求和
        
        z = self.sg1(z)  # 门控，压半通道并融合（SimpleGate 输出通道为原来的一半）
        x = self.sca(z) * z  # 通道注意力重标定（SE 样式：池化+1x1，然后与特征相乘）
        x = self.conv3(x)  # 投影回 C
        y = inp + self.beta * x  # 残差相加（beta 为可学习缩放，初始为 0 提升稳定性）
        #second step
        x = self.conv4(self.norm2(y)) # size [B, 2*C, H, W]  # 归一化后进入 FFN 第一步（通道扩展）
        x = self.sg2(x)  # size [B, C, H, W]  # 门控压半通道
        x = self.conv5(x) # size [B, C, H, W]  # 投影回 C
        x = y + x * self.gamma  # 残差相加（gamma 为可学习缩放，初始为 0）
        
#        if self.use_adapters:
#            return self.adapter(x)
#        else:
        return x  # 输出: [B, C, H, W]

class EBlock(nn.Module):  # 高效块：多分支 + 频域调制
    '''
    Change this block using Branch
    '''
    
    def __init__(self, c, DW_Expand=2, dilations = [1], extra_depth_wise = False):
        super().__init__()
        #we define the 2 branches
        self.dw_channel = DW_Expand * c  # 分支处理的扩展通道（EBlock 分支在原通道 c 上进行 DW_Expand 倍特征提取）
        self.extra_conv = nn.Conv2d(c, c, kernel_size=3, padding=1, stride=1, groups=c, bias=True, dilation=1) if extra_depth_wise else nn.Identity() # 可选额外深度卷积
        self.conv1 = nn.Conv2d(in_channels=c, out_channels=self.dw_channel, kernel_size=1, padding=0, stride=1, groups=1, bias=True, dilation = 1)  # 1x1 扩展
                
        self.branches = nn.ModuleList()
        for dilation in dilations:
            self.branches.append(Branch(c, DW_Expand, dilation = dilation))  # 并行空洞分支
            
        assert len(dilations) == len(self.branches)  # 合法性检查
        self.dw_channel = DW_Expand * c  # 供 SCA 计算通道
        self.sca = nn.Sequential(
                       nn.AdaptiveAvgPool2d(1),  # 全局池化
                       nn.Conv2d(in_channels=self.dw_channel // 2, out_channels=self.dw_channel // 2, kernel_size=1, padding=0, stride=1,
                       groups=1, bias=True, dilation = 1),  
        )  # 门控后的简单通道注意力
        self.sg1 = SimpleGate()  # 聚合分支后的门控（输出通道减半）
        self.conv3 = nn.Conv2d(in_channels=self.dw_channel // 2, out_channels=c, kernel_size=1, padding=0, stride=1, groups=1, bias=True, dilation = 1)  # 投影回 C
        # second step

        self.norm1 = LayerNorm2d(c)  # 分支前归一化
        self.norm2 = LayerNorm2d(c)  # 频域调制前归一化
        self.freq = FreMLP(nc = c, expand=2)  # 频域调制模块（对特征进行频域幅值调整）
        self.gamma = nn.Parameter(torch.zeros((1, c, 1, 1)), requires_grad=True)  # 频域阶段残差缩放
        self.beta = nn.Parameter(torch.zeros((1, c, 1, 1)), requires_grad=True)  # 分支阶段残差缩放


#        self.adapter = Adapter(c, ffn_channel=None)  # Optional adapter (disabled)
        
#        self.use_adapters = False  # Adapter flag (unused)

#    def set_use_adapters(self, use_adapters):
#        self.use_adapters = use_adapters

    def forward(self, inp):  # inp: [B, C, H, W]
        y = inp  # 残差基线（与输出相加）
        x = self.norm1(inp)  # 归一化
        x = self.conv1(self.extra_conv(x))  # 可选深度卷积 + 1x1 扩展（先空间建模再通道变换）
        z = 0  # 分支累加器
        for branch in self.branches:
            z += branch(x)  # 分支输出求和
        
        z = self.sg1(z)  # 门控压半通道
        x = self.sca(z) * z  # 通道注意力重标定（池化生成通道权重）
        x = self.conv3(x)  # 投影回 C
        y = inp + self.beta * x  # 残差叠加
        #second step
        x_step2 = self.norm2(y) # size [B, 2*C, H, W]  # 频域调制前归一化（规范数值范围）
        x_freq = self.freq(x_step2) # size [B, C, H, W]  # 频域调制张量（与 y 逐元素相乘）
        x = y * x_freq  # 逐元素调制特征（频域响应作为门控/增益）
        x = y + x * self.gamma  # 残差相加（缩放）

#        if self.use_adapters:
#            return self.adapter(x)
#        else:
        return x  # 输出: [B, C, H, W]

#----------------------------------------------------------------------------------------------
if __name__ == '__main__':  # 本地快速测试：统计 MACs/参数并做前向
    
    img_channel = 3  # 测试通道数
    width = 32  # 此处未使用（历史遗留）

    enc_blks = [1, 2, 3]  # 未使用（历史遗留）
    middle_blk_num = 3  # 未使用（历史遗留）
    dec_blks = [3, 1, 1]  # 未使用（历史遗留）
    dilations = [1, 4, 9]  # 示例空洞率
    extra_depth_wise = True  # 是否启用额外深度卷积
    
    # net = NAFNet(img_channel=img_channel, width=width, middle_blk_num=middle_blk_num,
    #                   enc_blk_nums=enc_blks, dec_blk_nums=dec_blks)
    net  = EBlock(c = img_channel, 
                            dilations = dilations,
                            extra_depth_wise=extra_depth_wise)  # 用于统计的 EBlock 实例

    inp_shape = (3, 256, 256)  # 用于 FLOPs/参数统计的虚拟输入尺寸

    from ptflops import get_model_complexity_info  # FLOPs/参数统计工具

    macs, params = get_model_complexity_info(net, inp_shape, verbose=False, print_per_layer_stat=False)  # 统计复杂度
    output = net(torch.randn((4, 3, 256, 256)))  # 简单前向验证
    # print('Values of EBlock:')
    print(macs, params)  # 打印 MACs 与参数量

    channels = 128  # 未使用（历史遗留）
    resol = 32  # 未使用（历史遗留）
    ksize = 5  # 未使用（历史遗留）

    # net = FAC(channels=channels, ksize=ksize)
    # inp_shape = (channels, resol, resol)
    # macs, params = get_model_complexity_info(net, inp_shape, verbose=False, print_per_layer_stat=True)
    # print('Values of FAC:')
    # print(macs, params)
