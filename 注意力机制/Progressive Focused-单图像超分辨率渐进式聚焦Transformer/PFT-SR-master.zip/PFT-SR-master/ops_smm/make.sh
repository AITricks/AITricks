#!/usr/bin/env bash
# --------------------------------------------------------
# SMM - Sparse Matrix Multiplication
# Licensed under The MIT License [see LICENSE for details]
# --------------------------------------------------------


# python setup.py develop

#python setup.py bdist_wheel

python setup.py install