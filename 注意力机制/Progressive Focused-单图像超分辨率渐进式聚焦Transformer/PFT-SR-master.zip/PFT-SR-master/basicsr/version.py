# GENERATED VERSION FILE
# TIME: Thu Mar 27 15:33:09 2025
__version__ = '0.1.1'
__gitsha__ = 'unknown'
version_info = (0, 1, 1)
