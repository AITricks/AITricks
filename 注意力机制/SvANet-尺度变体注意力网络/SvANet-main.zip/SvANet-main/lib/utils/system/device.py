import torch.cuda as Cuda


CUDA_AVAI = Cuda.is_available()