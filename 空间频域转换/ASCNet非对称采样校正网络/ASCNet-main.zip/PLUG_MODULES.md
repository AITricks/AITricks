## 可插拔模块使用说明（ASCNet）

本仓库已将 ASCNet 中的可即插即用模块抽离至 `model/plug_modules.py`，便于在不同网络中快速复用与替换。

### 包含模块
- RCSSC: 残差列空间自校正块（包含空间注意力与通道注意力）。
- NewBlock: 对应论文中的 CNCM，内部堆叠两个 RCSSC，并含级联与压缩卷积。
- RHDWTBlock: 残差 Haar 离散小波变换块（可选依赖 `pytorch_wavelets`；没有则自动退化为步长卷积近似实现）。
- PixelShuffleUpsample: 基于 PixelShuffle 的上采样封装。

### 环境准备
- Python 3.8+
- PyTorch（示例在 `torch>=1.8` 下测试）
- 可选：`pytorch_wavelets`（用于 RHDWTBlock 的真实小波变换）

安装可选依赖：
```bash
pip install pytorch_wavelets
```

### 快速运行测试
直接运行模块自带的演示：
```bash
python -m model.plug_modules
```
预期打印各模块的输入/输出张量尺寸，验证前向能正常执行。

### 在你自己的模型中使用
```python
from model.plug_modules import RCSSC, NewBlock, RHDWTBlock, PixelShuffleUpsample
import torch.nn as nn

class MyNet(nn.Module):
    def __init__(self, c=32):
        super().__init__()
        self.cncm = NewBlock(channel_in=c, reduction=16)
        self.rh = RHDWTBlock(in_channels=c, out_channels=2*c)  # 下采样 + 残差
        self.rcssc = RCSSC(n_feat=c)
        self.up = PixelShuffleUpsample(upscale_factor=2)

    def forward(self, x):
        x = self.cncm(x)
        x = self.rh(x)
        # 上采样前需准备 r^2 倍通道（例如通过 1x1 卷积扩展通道）
        # x = conv_expand(x)  # 示例
        return x
```

### 与原 ASCNet 的对应关系
- CNCM ↔ `NewBlock`
- RCSSC ↔ `RCSSC`
- RHDWT ↔ `RHDWTBlock`
- Pixel Shuffle ↔ `PixelShuffleUpsample`

### 注意事项
- RHDWTBlock 在未安装 `pytorch_wavelets` 时会使用步长卷积近似，实现可运行但与论文精确实现略有差异。
- PixelShuffle 上采样要求输入通道数满足 `out_channels = in_channels / r^2`，使用前需通过卷积调整通道。


