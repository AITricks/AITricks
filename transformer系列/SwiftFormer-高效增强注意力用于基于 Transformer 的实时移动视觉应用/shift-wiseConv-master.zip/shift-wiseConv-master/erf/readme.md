# for ERFs
`python erf/visualize_erf.py --model ShiftWise_v2 --data_path  /path/to/imagenet2012`

