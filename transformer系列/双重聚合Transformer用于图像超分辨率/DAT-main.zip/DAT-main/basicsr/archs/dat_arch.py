# 导入PyTorch核心模块
import torch  # PyTorch深度学习框架
import torch.nn as nn  # 神经网络模块
import torch.utils.checkpoint as checkpoint  # 梯度检查点，用于节省内存
from torch import Tensor  # 张量类型
from torch.nn import functional as F  # 函数式接口

# 导入第三方库
from timm.models.layers import DropPath, trunc_normal_  # 路径丢弃和权重初始化
from einops.layers.torch import Rearrange  # 张量重排操作
from einops import rearrange  # 张量重排函数

# 导入标准库
import math  # 数学函数
import numpy as np  # 数值计算库

# 导入项目内部模块
from basicsr.utils.registry import ARCH_REGISTRY  # 架构注册器


def img2windows(img, H_sp, W_sp):
    """
    将图像分割成窗口（windows）
    
    Args:
        img: 输入图像张量，形状为 (B, C, H, W)
        H_sp: 窗口的高度
        W_sp: 窗口的宽度
    
    Returns:
        窗口分割后的张量，形状为 (B', N, C)，其中B'是窗口数量，N是每个窗口的像素数
    """
    B, C, H, W = img.shape  # 获取批次大小、通道数、高度、宽度
    # 将图像重塑为窗口形式：(B, C, H//H_sp, H_sp, W//W_sp, W_sp)
    # view操作将图像分割成多个窗口，每个窗口大小为H_sp×W_sp
    img_reshape = img.view(B, C, H // H_sp, H_sp, W // W_sp, W_sp)
    # 重新排列维度：将(B, C, H//H_sp, H_sp, W//W_sp, W_sp)变为(B, H//H_sp, W//W_sp, H_sp, W_sp, C)
    # 然后展平为(B', H_sp*W_sp, C)，其中B' = B * (H//H_sp) * (W//W_sp)是窗口总数
    img_perm = img_reshape.permute(0, 2, 4, 3, 5, 1).contiguous().reshape(-1, H_sp* W_sp, C)
    return img_perm  # 返回窗口分割后的张量


def windows2img(img_splits_hw, H_sp, W_sp, H, W):
    """
    将窗口分割的张量重新组合成图像
    
    Args:
        img_splits_hw: 窗口分割的张量，形状为 (B', N, C)
        H_sp: 窗口的高度
        W_sp: 窗口的宽度
        H: 目标图像的高度
        W: 目标图像的宽度
    
    Returns:
        重新组合的图像张量，形状为 (B, H, W, C)
    """
    # 计算原始批次大小：B' = B * (H//H_sp) * (W//W_sp)，所以B = B' / ((H//H_sp) * (W//W_sp))
    # 其中(H * W / H_sp / W_sp) = (H//H_sp) * (W//W_sp)是窗口总数
    B = int(img_splits_hw.shape[0] / (H * W / H_sp / W_sp))

    # 将窗口张量重塑为图像形式：(B, H//H_sp, W//W_sp, H_sp, W_sp, C)
    # 将(B', H_sp*W_sp, C)重新组织为窗口块的形式
    img = img_splits_hw.view(B, H // H_sp, W // W_sp, H_sp, W_sp, -1)
    # 重新排列维度：(B, H//H_sp, W//W_sp, H_sp, W_sp, C) -> (B, H//H_sp, H_sp, W//W_sp, W_sp, C)
    # 然后展平为(B, H, W, C)，将多个窗口重新拼接成完整图像
    img = img.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    return img  # 返回重新组合后的完整图像张量


class SpatialGate(nn.Module):
    """ 
    空间门控模块，用于在空间维度上进行特征选择
    
    Args:
        dim (int): 输入通道数的一半
    """
    def __init__(self, dim):
        super().__init__()
        self.norm = nn.LayerNorm(dim)  # 层归一化
        # 深度可分离卷积，用于空间特征提取
        self.conv = nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1, groups=dim) # DW Conv

    def forward(self, x, H, W):
        """
        前向传播
        
        Args:
            x: 输入张量，形状为 (B, N, C)
            H: 图像高度
            W: 图像宽度
        
        Returns:
            门控后的特征，形状为 (B, N, C//2)
        """
        # 将输入特征沿最后一个维度（通道维度）分成两部分，每部分大小为C//2
        x1, x2 = x.chunk(2, dim = -1)
        B, N, C = x.shape  # 获取批次大小、序列长度（像素数）、通道数
        # 对x2进行处理：先进行层归一化，然后转换为空间格式(B, C//2, H, W)
        # 应用深度可分离卷积进行空间特征提取，最后再转换回序列格式(B, N, C//2)
        x2 = self.norm(x2)  # 层归一化：(B, N, C//2)
        x2 = x2.transpose(1, 2).contiguous()  # 转换为(B, C//2, N)
        x2 = x2.view(B, C//2, H, W)  # 重塑为空间格式(B, C//2, H, W)
        x2 = self.conv(x2)  # 深度可分离卷积：(B, C//2, H, W)
        x2 = x2.flatten(2)  # 展平空间维度：(B, C//2, H*W)
        x2 = x2.transpose(-1, -2).contiguous()  # 转置为(B, H*W, C//2)

        # 返回门控结果：x1与x2进行逐元素相乘，实现空间门控机制
        return x1 * x2


class SGFN(nn.Module):
    """ 
    空间门控前馈网络 (Spatial-Gate Feed-Forward Network)
    
    Args:
        in_features (int): 输入通道数
        hidden_features (int | None): 隐藏层通道数，默认为None
        out_features (int | None): 输出通道数，默认为None
        act_layer (nn.Module): 激活函数层，默认为nn.GELU
        drop (float): Dropout比率，默认为0.0
    """
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features  # 如果没有指定输出特征数，使用输入特征数
        hidden_features = hidden_features or in_features  # 如果没有指定隐藏特征数，使用输入特征数
        self.fc1 = nn.Linear(in_features, hidden_features)  # 第一个全连接层
        self.act = act_layer()  # 激活函数
        self.sg = SpatialGate(hidden_features//2)  # 空间门控模块
        self.fc2 = nn.Linear(hidden_features//2, out_features)  # 第二个全连接层
        self.drop = nn.Dropout(drop)  # Dropout层

    def forward(self, x, H, W):
        """
        前向传播
        
        Args:
            x: 输入张量，形状为 (B, H*W, C)
            H: 图像高度
            W: 图像宽度
        
        Returns:
            输出张量，形状为 (B, H*W, C)
        """
        x = self.fc1(x)  # 第一个全连接层：将输入特征从in_features维度扩展到hidden_features维度
        x = self.act(x)  # 激活函数：应用GELU等激活函数，引入非线性
        x = self.drop(x)  # Dropout：随机丢弃部分神经元，防止过拟合

        x = self.sg(x, H, W)  # 空间门控：应用空间门控机制，输出维度变为hidden_features//2
        x = self.drop(x)  # Dropout：再次应用Dropout

        x = self.fc2(x)  # 第二个全连接层：将特征从hidden_features//2映射回out_features维度
        x = self.drop(x)  # Dropout：最后一次Dropout
        return x  # 返回处理后的特征张量


class DynamicPosBias(nn.Module):
    # 实现基于Crossformer代码 https://github.com/cheerss/CrossFormer/blob/main/models/crossformer.py
    """ 
    动态相对位置偏置模块
    
    Args:
        dim (int): 输入通道数
        num_heads (int): 注意力头数
        residual (bool): 如果为True，使用残差连接策略
    """
    def __init__(self, dim, num_heads, residual):
        super().__init__()
        self.residual = residual  # 是否使用残差连接
        self.num_heads = num_heads  # 注意力头数
        self.pos_dim = dim // 4  # 位置编码维度
        self.pos_proj = nn.Linear(2, self.pos_dim)  # 位置投影层，将2D坐标映射到pos_dim维
        # 第一个位置编码处理序列
        self.pos1 = nn.Sequential(
            nn.LayerNorm(self.pos_dim),  # 层归一化
            nn.ReLU(inplace=True),  # ReLU激活
            nn.Linear(self.pos_dim, self.pos_dim),  # 线性变换
        )
        # 第二个位置编码处理序列
        self.pos2 = nn.Sequential(
            nn.LayerNorm(self.pos_dim),  # 层归一化
            nn.ReLU(inplace=True),  # ReLU激活
            nn.Linear(self.pos_dim, self.pos_dim)  # 线性变换
        )
        # 第三个位置编码处理序列，输出注意力头数
        self.pos3 = nn.Sequential(
            nn.LayerNorm(self.pos_dim),  # 层归一化
            nn.ReLU(inplace=True),  # ReLU激活
            nn.Linear(self.pos_dim, self.num_heads)  # 输出注意力头数
        )
    
    def forward(self, biases):
        """
        前向传播
        
        Args:
            biases: 位置偏置张量，形状为 (2Gh-1 * 2Gw-1, 2)，包含所有相对位置的2D坐标
        
        Returns:
            动态位置偏置，形状为 (2Gh-1 * 2Gw-1, num_heads)，每个头都有对应的位置偏置
        """
        if self.residual:
            # 使用残差连接的方式：有助于梯度流动和训练稳定性
            pos = self.pos_proj(biases)  # 位置投影：将2D坐标从2维映射到pos_dim维 (2Gh-1 * 2Gw-1, pos_dim)
            pos = pos + self.pos1(pos)  # 第一个处理序列 + 残差连接：增强特征表达
            pos = pos + self.pos2(pos)  # 第二个处理序列 + 残差连接：进一步处理
            pos = self.pos3(pos)  # 最终输出：映射到注意力头数维度 (2Gh-1 * 2Gw-1, num_heads)
        else:
            # 不使用残差连接，直接串联：顺序通过三个处理序列
            pos = self.pos_proj(biases)  # 位置投影
            pos = self.pos1(pos)  # 第一个处理序列
            pos = self.pos2(pos)  # 第二个处理序列
            pos = self.pos3(pos)  # 最终输出
        return pos  # 返回动态位置偏置，将用于添加到注意力分数中


class Spatial_Attention(nn.Module):
    """ 
    空间窗口自注意力机制
    支持矩形窗口（包含正方形窗口）
    
    Args:
        dim (int): 输入通道数
        idx (int): 窗口索引 (0/1)
        split_size (tuple(int)): 空间窗口的高度和宽度
        dim_out (int | None): 注意力输出的维度，默认为None
        num_heads (int): 注意力头数，默认为6
        attn_drop (float): 注意力权重的Dropout比率，默认为0.0
        proj_drop (float): 输出的Dropout比率，默认为0.0
        qk_scale (float | None): 如果设置，覆盖默认的qk缩放因子 head_dim ** -0.5
        position_bias (bool): 是否使用动态相对位置偏置，默认为True
    """
    def __init__(self, dim, idx, split_size=[8,8], dim_out=None, num_heads=6, attn_drop=0., proj_drop=0., qk_scale=None, position_bias=True):
        super().__init__()
        self.dim = dim  # 输入维度
        self.dim_out = dim_out or dim  # 输出维度
        self.split_size = split_size  # 分割尺寸
        self.num_heads = num_heads  # 注意力头数
        self.idx = idx  # 窗口索引
        self.position_bias = position_bias  # 是否使用位置偏置

        head_dim = dim // num_heads  # 每个头的维度
        self.scale = qk_scale or head_dim ** -0.5  # 缩放因子

        # 根据窗口索引设置窗口尺寸
        if idx == 0:
            H_sp, W_sp = self.split_size[0], self.split_size[1]  # 正常方向
        elif idx == 1:
            W_sp, H_sp = self.split_size[0], self.split_size[1]  # 交换方向
        else:
            print ("ERROR MODE", idx)
            exit(0)
        self.H_sp = H_sp  # 窗口高度
        self.W_sp = W_sp  # 窗口宽度

        if self.position_bias:
            self.pos = DynamicPosBias(self.dim // 4, self.num_heads, residual=False)
            # generate mother-set
            position_bias_h = torch.arange(1 - self.H_sp, self.H_sp)
            position_bias_w = torch.arange(1 - self.W_sp, self.W_sp)
            biases = torch.stack(torch.meshgrid([position_bias_h, position_bias_w], indexing='ij'))
            biases = biases.flatten(1).transpose(0, 1).contiguous().float()
            self.register_buffer('rpe_biases', biases)

            # get pair-wise relative position index for each token inside the window
            coords_h = torch.arange(self.H_sp)
            coords_w = torch.arange(self.W_sp)
            coords = torch.stack(torch.meshgrid([coords_h, coords_w], indexing='ij'))
            coords_flatten = torch.flatten(coords, 1)
            relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]
            relative_coords = relative_coords.permute(1, 2, 0).contiguous()
            relative_coords[:, :, 0] += self.H_sp - 1
            relative_coords[:, :, 1] += self.W_sp - 1
            relative_coords[:, :, 0] *= 2 * self.W_sp - 1
            relative_position_index = relative_coords.sum(-1)
            self.register_buffer('relative_position_index', relative_position_index)

        self.attn_drop = nn.Dropout(attn_drop)

    def im2win(self, x, H, W):
        """
        将图像token序列转换为窗口形式，并准备好用于多头注意力计算
        
        Args:
            x: 输入张量，形状为 (B, N, C)，其中N=H*W
            H: 图像高度
            W: 图像宽度
        
        Returns:
            窗口形式的张量，形状为 (B', num_heads, H_sp*W_sp, head_dim)
        """
        B, N, C = x.shape  # 获取批次大小、序列长度、通道数
        # 将序列格式转换为空间格式：(B, N, C) -> (B, C, H, W)
        x = x.transpose(-2,-1).contiguous().view(B, C, H, W)
        # 使用img2windows函数将图像分割成窗口：(B, C, H, W) -> (B', H_sp*W_sp, C)
        # 其中B' = B * (H//H_sp) * (W//W_sp)是窗口总数
        x = img2windows(x, self.H_sp, self.W_sp)
        # 重塑为多头注意力格式：(B', H_sp*W_sp, C) -> (B', H_sp*W_sp, num_heads, head_dim)
        # 然后转置为(B', num_heads, H_sp*W_sp, head_dim)，便于后续注意力计算
        x = x.reshape(-1, self.H_sp* self.W_sp, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3).contiguous()
        return x  # 返回窗口形式的多头张量

    def forward(self, qkv, H, W, mask=None):
        """
        空间窗口自注意力的前向传播
        
        Input: 
            qkv: 包含query、key、value的元组，每个形状为 (B, L, C)，其中L=H*W
            H: 图像高度
            W: 图像宽度
            mask: 注意力掩码，形状为 (nW, N, N)，用于shift window，默认为None
        
        Output: 
            x: 注意力输出，形状为 (B, H, W, C)
        """
        q, k, v = qkv[0], qkv[1], qkv[2]  # 从输入元组中分离出query、key、value

        B, L, C = q.shape  # 获取批次大小、序列长度、通道数
        assert L == H * W, "flatten img_tokens has wrong size"  # 断言：确保序列长度等于图像像素数

        # 将q、k、v从图像形式分割为窗口形式，并准备多头注意力计算
        q = self.im2win(q, H, W)  # (B', num_heads, H_sp*W_sp, head_dim)
        k = self.im2win(k, H, W)  # (B', num_heads, H_sp*W_sp, head_dim)
        v = self.im2win(v, H, W)  # (B', num_heads, H_sp*W_sp, head_dim)

        # 缩放query，用于稳定梯度（缩放因子为1/sqrt(head_dim)）
        q = q * self.scale
        # 计算注意力分数：Q @ K^T，得到每个位置对其他位置的注意力权重
        # 形状：(B', num_heads, H_sp*W_sp, H_sp*W_sp)
        attn = (q @ k.transpose(-2, -1))  # B head N C @ B head C N --> B head N N

        # 计算动态相对位置偏置（Dynamic Relative Position Embedding, DRPE）
        if self.position_bias:
            # 通过位置偏置网络生成位置偏置
            pos = self.pos(self.rpe_biases)  # (2Gh-1 * 2Gw-1, num_heads)
            # 根据相对位置索引选择对应的位置偏置
            # 将位置偏置重塑为注意力矩阵的形状
            relative_position_bias = pos[self.relative_position_index.view(-1)].view(
                self.H_sp * self.W_sp, self.H_sp * self.W_sp, -1)  # (H_sp*W_sp, H_sp*W_sp, num_heads)
            # 转置为(num_heads, H_sp*W_sp, H_sp*W_sp)以匹配注意力矩阵的维度
            relative_position_bias = relative_position_bias.permute(2, 0, 1).contiguous()
            # 将位置偏置添加到注意力分数中（增加batch维度以支持广播）
            attn = attn + relative_position_bias.unsqueeze(0)  # (B', num_heads, H_sp*W_sp, H_sp*W_sp)

        N = attn.shape[3]  # 获取窗口内的token数量（即H_sp*W_sp）

        # 如果使用shift window，需要应用掩码来避免不同窗口之间的不必要连接
        if mask is not None:
            nW = mask.shape[0]  # 窗口数量
            # 将注意力矩阵重塑以包含窗口维度，然后添加掩码
            attn = attn.view(B, nW, self.num_heads, N, N) + mask.unsqueeze(1).unsqueeze(0)
            # 重新展平为窗口格式
            attn = attn.view(-1, self.num_heads, N, N)

        # 应用softmax归一化注意力权重，使得每行的权重和为1
        attn = nn.functional.softmax(attn, dim=-1, dtype=attn.dtype)
        # 应用注意力dropout，随机丢弃部分注意力权重以防止过拟合
        attn = self.attn_drop(attn)

        # 使用注意力权重对value进行加权求和，得到注意力输出
        x = (attn @ v)  # (B', num_heads, H_sp*W_sp, head_dim)
        # 转置并重塑：将多头输出合并并转换为窗口序列格式
        x = x.transpose(1, 2).reshape(-1, self.H_sp* self.W_sp, C)  # (B', H_sp*W_sp, C)

        # 将窗口重新合并为图像格式
        x = windows2img(x, self.H_sp, self.W_sp, H, W)  # (B, H, W, C)

        return x  # 返回注意力输出


class Adaptive_Spatial_Attention(nn.Module):
    # The implementation builds on CAT code https://github.com/Zhengchen1999/CAT
    """ Adaptive Spatial Self-Attention
    Args:
        dim (int): Number of input channels.
        num_heads (int): Number of attention heads. Default: 6
        split_size (tuple(int)): Height and Width of spatial window.
        shift_size (tuple(int)): Shift size for spatial window.
        qkv_bias (bool): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None): Override default qk scale of head_dim ** -0.5 if set.
        drop (float): Dropout rate. Default: 0.0
        attn_drop (float): Attention dropout rate. Default: 0.0
        rg_idx (int): The indentix of Residual Group (RG)
        b_idx (int): The indentix of Block in each RG
    """
    def __init__(self, dim, num_heads, 
                 reso=64, split_size=[8,8], shift_size=[1,2], qkv_bias=False, qk_scale=None,
                 drop=0., attn_drop=0., rg_idx=0, b_idx=0):
        super().__init__()
        self.dim = dim  # 输入通道维度
        self.num_heads = num_heads  # 注意力头数
        self.split_size = split_size  # 空间窗口的分割尺寸，如[8,8]表示8×8的窗口
        self.shift_size = shift_size  # 窗口的平移尺寸，用于shift window机制
        self.b_idx  = b_idx  # 当前block在ResidualGroup中的索引
        self.rg_idx = rg_idx  # 当前ResidualGroup的索引
        self.patches_resolution = reso  # 输入图像的分辨率（patch级别）
        # 生成query、key、value的线性层，输出维度为dim*3（分别对应q、k、v）
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)

        # 断言：确保shift_size在合理范围内，必须小于split_size
        assert 0 <= self.shift_size[0] < self.split_size[0], "shift_size must in 0-split_size0"
        assert 0 <= self.shift_size[1] < self.split_size[1], "shift_size must in 0-split_size1"

        self.branch_num = 2  # 分支数量，使用两个并行的空间注意力分支

        # 输出投影层和dropout层
        self.proj = nn.Linear(dim, dim)  # 输出投影层，将特征映射回原始维度
        self.proj_drop = nn.Dropout(drop)  # 投影后的dropout层

        # 创建两个空间注意力分支，每个分支处理一半的通道
        # 两个分支使用不同的窗口方向（idx=0和idx=1）
        self.attns = nn.ModuleList([
                Spatial_Attention(
                    dim//2, idx = i,  # 每个分支的维度为dim//2，使用不同的窗口索引
                    split_size=split_size, num_heads=num_heads//2, dim_out=dim//2,
                    qk_scale=qk_scale, attn_drop=attn_drop, proj_drop=drop, position_bias=True)
                for i in range(self.branch_num)])

        # 根据block和group的索引决定是否使用shift window掩码
        # 规则：在特定block中（如第2、6、10...个block）需要shift window，因此需要掩码
        if (self.rg_idx % 2 == 0 and self.b_idx  > 0 and (self.b_idx  - 2) % 4 == 0) or (self.rg_idx % 2 != 0 and self.b_idx  % 4 == 0):
            # 计算注意力掩码，用于shift window时避免不同窗口之间的错误连接
            attn_mask = self.calculate_mask(self.patches_resolution, self.patches_resolution)
            # 注册为buffer，使其成为模型状态的一部分（但不参与梯度更新）
            self.register_buffer("attn_mask_0", attn_mask[0])  # 第一个分支的掩码
            self.register_buffer("attn_mask_1", attn_mask[1])  # 第二个分支的掩码
        else:
            # 不需要shift window时，掩码为None
            attn_mask = None
            self.register_buffer("attn_mask_0", None)
            self.register_buffer("attn_mask_1", None)
        
        # 深度可分离卷积分支：用于提取局部空间特征
        self.dwconv = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1,groups=dim),  # 深度可分离卷积
            nn.BatchNorm2d(dim),  # 批量归一化，稳定训练
            nn.GELU()  # GELU激活函数
        )
        # 通道交互模块：生成通道注意力图（C-Map），用于自适应交互
        self.channel_interaction = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),  # 全局平均池化，得到每个通道的全局特征
            nn.Conv2d(dim, dim // 8, kernel_size=1),  # 降维：减少计算量
            nn.BatchNorm2d(dim // 8),  # 批量归一化
            nn.GELU(),  # GELU激活
            nn.Conv2d(dim // 8, dim, kernel_size=1),  # 恢复到原始维度，输出通道注意力图
        )
        # 空间交互模块：生成空间注意力图（S-Map），用于自适应交互
        self.spatial_interaction = nn.Sequential(
            nn.Conv2d(dim, dim // 16, kernel_size=1),  # 降维：减少计算量
            nn.BatchNorm2d(dim // 16),  # 批量归一化
            nn.GELU(),  # GELU激活
            nn.Conv2d(dim // 16, 1, kernel_size=1)  # 输出单通道空间注意力图
        )

    def calculate_mask(self, H, W):
        """
        计算shift window时的注意力掩码
        该实现基于Swin Transformer代码：https://github.com/microsoft/Swin-Transformer/blob/main/models/swin_transformer.py
        
        Args:
            H: 图像高度
            W: 图像宽度
        
        Returns:
            attn_mask_0, attn_mask_1: 两个分支的注意力掩码，形状为(nW, N, N)
        """
        # calculate attention mask for shift window
        # 创建两个掩码张量，分别用于两个不同方向的窗口
        img_mask_0 = torch.zeros((1, H, W, 1))  # 第一个分支的掩码，形状为(1, H, W, 1)
        img_mask_1 = torch.zeros((1, H, W, 1))  # 第二个分支的掩码，形状为(1, H, W, 1)
        
        # 定义第一个分支的三个高度切片区域（用于shift window划分）
        h_slices_0 = (slice(0, -self.split_size[0]),  # 从开始到倒数第split_size[0]行
                    slice(-self.split_size[0], -self.shift_size[0]),  # 中间区域
                    slice(-self.shift_size[0], None))  # 最后shift_size[0]行
        # 定义第一个分支的三个宽度切片区域
        w_slices_0 = (slice(0, -self.split_size[1]),  # 从开始到倒数第split_size[1]列
                    slice(-self.split_size[1], -self.shift_size[1]),  # 中间区域
                    slice(-self.shift_size[1], None))  # 最后shift_size[1]列

        # 定义第二个分支的高度和宽度切片（方向交换）
        h_slices_1 = (slice(0, -self.split_size[1]),  # 使用split_size[1]作为高度切片
                    slice(-self.split_size[1], -self.shift_size[1]),
                    slice(-self.shift_size[1], None))
        w_slices_1 = (slice(0, -self.split_size[0]),  # 使用split_size[0]作为宽度切片
                    slice(-self.split_size[0], -self.shift_size[0]),
                    slice(-self.shift_size[0], None))
        
        # 为第一个分支的掩码分配区域编号
        cnt = 0  # 计数器，用于给不同区域分配不同的编号
        for h in h_slices_0:  # 遍历高度切片
            for w in w_slices_0:  # 遍历宽度切片
                img_mask_0[:, h, w, :] = cnt  # 给当前区域的所有像素分配编号
                cnt += 1  # 编号递增
        # 为第二个分支的掩码分配区域编号
        cnt = 0  # 重置计数器
        for h in h_slices_1:
            for w in w_slices_1:
                img_mask_1[:, h, w, :] = cnt
                cnt += 1

        # 计算第一个分支的窗口掩码
        # 将掩码重塑为窗口形式：(1, H, W, 1) -> (1, H//split_size[0], split_size[0], W//split_size[1], split_size[1], 1)
        img_mask_0 = img_mask_0.view(1, H // self.split_size[0], self.split_size[0], W // self.split_size[1], self.split_size[1], 1)
        # 转置并重塑：(1, H//split_size[0], W//split_size[1], split_size[0], split_size[1], 1) -> (nW, split_size[0], split_size[1], 1)
        # 其中nW是窗口总数
        img_mask_0 = img_mask_0.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, self.split_size[0], self.split_size[1], 1)
        # 展平每个窗口：(nW, split_size[0], split_size[1], 1) -> (nW, split_size[0]*split_size[1])
        mask_windows_0 = img_mask_0.view(-1, self.split_size[0] * self.split_size[1])
        # 计算窗口内像素之间的掩码：如果两个像素来自不同区域，掩码为-100（softmax后接近0），否则为0
        attn_mask_0 = mask_windows_0.unsqueeze(1) - mask_windows_0.unsqueeze(2)  # (nW, N, N)
        # 将非零值（不同区域）设为-100，零值（相同区域）设为0
        attn_mask_0 = attn_mask_0.masked_fill(attn_mask_0 != 0, float(-100.0)).masked_fill(attn_mask_0 == 0, float(0.0))

        # 计算第二个分支的窗口掩码（类似操作，但窗口方向不同）
        img_mask_1 = img_mask_1.view(1, H // self.split_size[1], self.split_size[1], W // self.split_size[0], self.split_size[0], 1)
        img_mask_1 = img_mask_1.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, self.split_size[1], self.split_size[0], 1)
        mask_windows_1 = img_mask_1.view(-1, self.split_size[1] * self.split_size[0])
        attn_mask_1 = mask_windows_1.unsqueeze(1) - mask_windows_1.unsqueeze(2)
        attn_mask_1 = attn_mask_1.masked_fill(attn_mask_1 != 0, float(-100.0)).masked_fill(attn_mask_1 == 0, float(0.0))

        return attn_mask_0, attn_mask_1  # 返回两个分支的注意力掩码

    def forward(self, x, H, W):
        """
        自适应空间注意力的前向传播
        
        Input: 
            x: 输入张量，形状为 (B, H*W, C)
            H: 图像高度
            W: 图像宽度
        
        Output: 
            x: 输出张量，形状为 (B, H*W, C)
        """
        B, L, C = x.shape  # 获取批次大小、序列长度、通道数
        assert L == H * W, "flatten img_tokens has wrong size"  # 断言：确保序列长度等于图像像素数

        # 生成query、key、value，并重新排列维度
        # (B, H*W, C) -> (B, H*W, 3*C) -> (3, B, H*W, C)
        qkv = self.qkv(x).reshape(B, -1, 3, C).permute(2, 0, 1, 3)  # 形状：(3, B, HW, C)
        # 提取value并转换为空间格式（不进行窗口分割，用于卷积分支）
        v = qkv[2].transpose(-2,-1).contiguous().view(B, C, H, W)  # (B, C, H, W)

        # 图像填充：确保图像尺寸能被窗口大小整除
        max_split_size = max(self.split_size[0], self.split_size[1])  # 获取最大的窗口尺寸
        pad_l = pad_t = 0  # 左侧和顶部不填充
        # 计算右侧和底部的填充量，使W和H能被max_split_size整除
        pad_r = (max_split_size - W % max_split_size) % max_split_size
        pad_b = (max_split_size - H % max_split_size) % max_split_size

        # 将qkv转换为空间格式并进行填充
        qkv = qkv.reshape(3*B, H, W, C).permute(0, 3, 1, 2)  # (3B, C, H, W)
        # 填充：(pad_l, pad_r, pad_t, pad_b)表示左、右、上、下的填充
        qkv = F.pad(qkv, (pad_l, pad_r, pad_t, pad_b)).reshape(3, B, C, -1).transpose(-2, -1)
        _H = pad_b + H  # 填充后的高度
        _W = pad_r + W  # 填充后的宽度
        _L = _H * _W  # 填充后的像素总数

        # 窗口分割和shift window机制
        # 将通道分成两部分[C/2, C/2]，分别处理
        # shift的block模式：(0, 4, 8, ...), (2, 6, 10, ...), (0, 4, 8, ...), (2, 6, 10, ...), ...
        # 根据block和group的索引决定是否应用shift window
        if (self.rg_idx % 2 == 0 and self.b_idx  > 0 and (self.b_idx  - 2) % 4 == 0) or (self.rg_idx % 2 != 0 and self.b_idx  % 4 == 0):
            # 需要shift window的情况
            qkv = qkv.view(3, B, _H, _W, C)  # 转换为空间格式 (3, B, _H, _W, C)
            # 对第一个分支（前C//2通道）进行shift
            qkv_0 = torch.roll(qkv[:,:,:,:,:C//2], shifts=(-self.shift_size[0], -self.shift_size[1]), dims=(2, 3))
            qkv_0 = qkv_0.view(3, B, _L, C//2)  # 重塑为序列格式
            # 对第二个分支（后C//2通道）进行shift，方向相反
            qkv_1 = torch.roll(qkv[:,:,:,:,C//2:], shifts=(-self.shift_size[1], -self.shift_size[0]), dims=(2, 3))
            qkv_1 = qkv_1.view(3, B, _L, C//2)  # 重塑为序列格式

            # 如果分辨率发生变化，需要重新计算掩码
            if self.patches_resolution != _H or self.patches_resolution != _W:
                mask_tmp = self.calculate_mask(_H, _W)  # 临时计算掩码
                # 使用临时掩码进行注意力计算
                x1_shift = self.attns[0](qkv_0, _H, _W, mask=mask_tmp[0].to(x.device))
                x2_shift = self.attns[1](qkv_1, _H, _W, mask=mask_tmp[1].to(x.device))
            else:
                # 使用预计算的掩码
                x1_shift = self.attns[0](qkv_0, _H, _W, mask=self.attn_mask_0)
                x2_shift = self.attns[1](qkv_1, _H, _W, mask=self.attn_mask_1)

            # 将shift后的结果shift回来（逆操作）
            x1 = torch.roll(x1_shift, shifts=(self.shift_size[0], self.shift_size[1]), dims=(1, 2))
            x2 = torch.roll(x2_shift, shifts=(self.shift_size[1], self.shift_size[0]), dims=(1, 2))
            # 裁剪回原始尺寸并重塑为序列格式
            x1 = x1[:, :H, :W, :].reshape(B, L, C//2)
            x2 = x2[:, :H, :W, :].reshape(B, L, C//2)
            # 将两个分支的输出拼接
            attened_x = torch.cat([x1,x2], dim=2)  # (B, L, C)

        else:
            # 不需要shift window的情况，直接进行注意力计算
            x1 = self.attns[0](qkv[:,:,:,:C//2], _H, _W)[:, :H, :W, :].reshape(B, L, C//2)
            x2 = self.attns[1](qkv[:,:,:,C//2:], _H, _W)[:, :H, :W, :].reshape(B, L, C//2)
            # 将两个分支的输出拼接
            attened_x = torch.cat([x1,x2], dim=2)  # (B, L, C)
        
        # 卷积分支：使用深度可分离卷积提取局部特征
        conv_x = self.dwconv(v)  # (B, C, H, W)

        # Adaptive Interaction Module (AIM) - 自适应交互模块
        # 生成通道注意力图（C-Map）：从卷积特征中提取通道注意力
        channel_map = self.channel_interaction(conv_x)  # (B, C, 1, 1)
        channel_map = channel_map.permute(0, 2, 3, 1).contiguous().view(B, 1, C)  # (B, 1, C)
        # 生成空间注意力图（S-Map）：从注意力特征中提取空间注意力
        attention_reshape = attened_x.transpose(-2,-1).contiguous().view(B, C, H, W)  # (B, C, H, W)
        spatial_map = self.spatial_interaction(attention_reshape)  # (B, 1, H, W)

        # 通道交互（C-I）：使用通道注意力图调制注意力特征
        attened_x = attened_x * torch.sigmoid(channel_map)  # (B, L, C)
        # 空间交互（S-I）：使用空间注意力图调制卷积特征
        conv_x = torch.sigmoid(spatial_map) * conv_x  # (B, C, H, W)
        conv_x = conv_x.permute(0, 2, 3, 1).contiguous().view(B, L, C)  # (B, L, C)

        # 融合注意力分支和卷积分支的输出
        x = attened_x + conv_x  # (B, L, C)

        # 输出投影和dropout
        x = self.proj(x)  # 线性投影：(B, L, C)
        x = self.proj_drop(x)  # Dropout

        return x  # 返回最终输出


class Adaptive_Channel_Attention(nn.Module):
    # The implementation builds on XCiT code https://github.com/facebookresearch/xcit
    """ Adaptive Channel Self-Attention
    Args:
        dim (int): Number of input channels.
        num_heads (int): Number of attention heads. Default: 6
        qkv_bias (bool): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None): Override default qk scale of head_dim ** -0.5 if set.
        attn_drop (float): Attention dropout rate. Default: 0.0
        drop_path (float): Stochastic depth rate. Default: 0.0
    """
    def __init__(self, dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        self.num_heads = num_heads  # 注意力头数
        # 温度参数：可学习的缩放因子，用于调整注意力分布的锐度
        # 形状为(num_heads, 1, 1)，每个头都有独立的温度参数
        self.temperature = nn.Parameter(torch.ones(num_heads, 1, 1))

        # 生成query、key、value的线性层
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)  # 注意力权重的dropout层
        self.proj = nn.Linear(dim, dim)  # 输出投影层
        self.proj_drop = nn.Dropout(proj_drop)  # 投影后的dropout层

        # 深度可分离卷积分支：用于提取局部空间特征
        self.dwconv = nn.Sequential(
            nn.Conv2d(dim, dim, kernel_size=3, stride=1, padding=1,groups=dim),  # 深度可分离卷积
            nn.BatchNorm2d(dim),  # 批量归一化
            nn.GELU()  # GELU激活函数
        )
        # 通道交互模块：生成通道注意力图（C-Map），用于自适应交互
        self.channel_interaction = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),  # 全局平均池化，得到每个通道的全局特征
            nn.Conv2d(dim, dim // 8, kernel_size=1),  # 降维：减少计算量
            nn.BatchNorm2d(dim // 8),  # 批量归一化
            nn.GELU(),  # GELU激活
            nn.Conv2d(dim // 8, dim, kernel_size=1),  # 恢复到原始维度，输出通道注意力图
        )
        # 空间交互模块：生成空间注意力图（S-Map），用于自适应交互
        self.spatial_interaction = nn.Sequential(
            nn.Conv2d(dim, dim // 16, kernel_size=1),  # 降维：减少计算量
            nn.BatchNorm2d(dim // 16),  # 批量归一化
            nn.GELU(),  # GELU激活
            nn.Conv2d(dim // 16, 1, kernel_size=1)  # 输出单通道空间注意力图
        )

    def forward(self, x, H, W):
        """
        自适应通道注意力的前向传播
        
        Input: 
            x: 输入张量，形状为 (B, H*W, C)
            H: 图像高度
            W: 图像宽度
        
        Output: 
            x: 输出张量，形状为 (B, H*W, C)
        """
        B, N, C = x.shape  # 获取批次大小、序列长度（像素数）、通道数
        # 生成query、key、value，并重塑为多头形式
        # (B, N, C) -> (B, N, 3*C) -> (B, N, 3, num_heads, head_dim)
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads)
        # 转置为(3, B, num_heads, N, head_dim)，便于分离q、k、v
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # 分离出query、key、value

        # 转置：将通道维度放在最后，便于后续计算
        # (B, num_heads, N, head_dim) -> (B, num_heads, head_dim, N)
        q = q.transpose(-2, -1)  # (B, num_heads, head_dim, N)
        k = k.transpose(-2, -1)  # (B, num_heads, head_dim, N)
        v = v.transpose(-2, -1)  # (B, num_heads, head_dim, N)

        # 将v重塑为空间格式，用于卷积分支
        v_ = v.reshape(B, C, N).contiguous().view(B, C, H, W)  # (B, C, H, W)

        # 对query和key进行L2归一化，这是通道注意力的特点（不同于空间注意力）
        # 归一化后的点积注意力更稳定
        q = torch.nn.functional.normalize(q, dim=-1)  # 在head_dim维度归一化
        k = torch.nn.functional.normalize(k, dim=-1)  # 在head_dim维度归一化

        # 计算通道注意力：Q @ K^T，然后乘以温度参数
        # (B, num_heads, head_dim, N) @ (B, num_heads, N, head_dim) -> (B, num_heads, head_dim, head_dim)
        # 这里的注意力是在通道维度（head_dim）上计算的，而不是空间维度（N）
        attn = (q @ k.transpose(-2, -1)) * self.temperature  # 温度缩放
        attn = attn.softmax(dim=-1)  # 在最后一个维度（head_dim）上应用softmax
        attn = self.attn_drop(attn)  # 应用dropout

        # 注意力输出：使用注意力权重对value进行加权
        # (B, num_heads, head_dim, head_dim) @ (B, num_heads, head_dim, N) -> (B, num_heads, head_dim, N)
        # 然后转置并重塑为(B, N, C)
        attened_x = (attn @ v).permute(0, 3, 1, 2).reshape(B, N, C)

        # 卷积分支：使用深度可分离卷积提取局部特征
        conv_x = self.dwconv(v_)  # (B, C, H, W)

        # Adaptive Interaction Module (AIM) - 自适应交互模块
        # 生成通道注意力图（C-Map）：从注意力特征中提取通道注意力
        attention_reshape = attened_x.transpose(-2,-1).contiguous().view(B, C, H, W)  # (B, C, H, W)
        channel_map = self.channel_interaction(attention_reshape)  # (B, C, 1, 1)
        # 生成空间注意力图（S-Map）：从卷积特征中提取空间注意力
        spatial_map = self.spatial_interaction(conv_x)  # (B, 1, H, W)
        spatial_map = spatial_map.permute(0, 2, 3, 1).contiguous().view(B, N, 1)  # (B, N, 1)

        # 空间交互（S-I）：使用空间注意力图调制注意力特征
        attened_x = attened_x * torch.sigmoid(spatial_map)  # (B, N, C)
        # 通道交互（C-I）：使用通道注意力图调制卷积特征
        conv_x = conv_x * torch.sigmoid(channel_map)  # (B, C, H, W)
        conv_x = conv_x.permute(0, 2, 3, 1).contiguous().view(B, N, C)  # (B, N, C)

        # 融合注意力分支和卷积分支的输出
        x = attened_x + conv_x  # (B, N, C)

        # 输出投影和dropout
        x = self.proj(x)  # 线性投影
        x = self.proj_drop(x)  # Dropout

        return x  # 返回最终输出


class DATB(nn.Module):
    """
    双聚合Transformer Block (Dual Aggregation Transformer Block)
    根据block索引交替使用空间注意力和通道注意力
    """
    def __init__(self, dim, num_heads, reso=64, split_size=[2,4],shift_size=[1,2], expansion_factor=4., qkv_bias=False, qk_scale=None, drop=0.,
                 attn_drop=0., drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, rg_idx=0, b_idx=0):
        super().__init__()

        self.norm1 = norm_layer(dim)  # 第一个归一化层，用于注意力模块前

        # 根据block索引决定使用哪种注意力机制
        if b_idx % 2 == 0:
            # DSTB (Dual Spatial Transformer Block)：偶数索引使用空间注意力
            self.attn = Adaptive_Spatial_Attention(
                dim, num_heads=num_heads, reso=reso, split_size=split_size, shift_size=shift_size, qkv_bias=qkv_bias, qk_scale=qk_scale,
                drop=drop, attn_drop=attn_drop, rg_idx=rg_idx, b_idx=b_idx
            )
        else:
            # DCTB (Dual Channel Transformer Block)：奇数索引使用通道注意力
            self.attn = Adaptive_Channel_Attention(
                dim, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale, attn_drop=attn_drop,
                proj_drop=drop
            )
        # DropPath：随机深度，用于正则化和提高泛化能力
        # 当drop_path>0时使用DropPath，否则使用Identity（不做任何操作）
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()

        # 前馈网络（FFN）：使用空间门控前馈网络
        ffn_hidden_dim = int(dim * expansion_factor)  # FFN的隐藏层维度，通常是输入维度的4倍
        self.ffn = SGFN(in_features=dim, hidden_features=ffn_hidden_dim, out_features=dim, act_layer=act_layer)
        self.norm2 = norm_layer(dim)  # 第二个归一化层，用于FFN前

    def forward(self, x, x_size):
        """
        前向传播
        
        Input: 
            x: 输入张量，形状为 (B, H*W, C)
            x_size: 图像尺寸元组 (H, W)
        
        Output: 
            x: 输出张量，形状为 (B, H*W, C)
        """        
        H , W = x_size  # 解包图像高度和宽度
        # 第一个残差连接：注意力模块（Pre-Norm结构）
        # 先归一化，再通过注意力，再通过DropPath，最后与输入相加
        x = x + self.drop_path(self.attn(self.norm1(x), H, W))
        # 第二个残差连接：FFN模块（Pre-Norm结构）
        # 先归一化，再通过FFN，再通过DropPath，最后与输入相加
        x = x + self.drop_path(self.ffn(self.norm2(x), H, W))

        return x  # 返回处理后的特征


class ResidualGroup(nn.Module):
    """ ResidualGroup
    Args:
        dim (int): Number of input channels.
        reso (int): Input resolution.
        num_heads (int): Number of attention heads.
        split_size (tuple(int)): Height and Width of spatial window.
        expansion_factor (float): Ratio of ffn hidden dim to embedding dim.
        qkv_bias (bool): If True, add a learnable bias to query, key, value. Default: True
        qk_scale (float | None): Override default qk scale of head_dim ** -0.5 if set. Default: None
        drop (float): Dropout rate. Default: 0
        attn_drop(float): Attention dropout rate. Default: 0
        drop_paths (float | None): Stochastic depth rate.
        act_layer (nn.Module): Activation layer. Default: nn.GELU
        norm_layer (nn.Module): Normalization layer. Default: nn.LayerNorm
        depth (int): Number of dual aggregation Transformer blocks in residual group.
        use_chk (bool): Whether to use checkpointing to save memory.
        resi_connection: The convolutional block before residual connection. '1conv'/'3conv'
    """
    def __init__(   self,
                    dim,
                    reso,
                    num_heads,
                    split_size=[2,4],
                    expansion_factor=4.,
                    qkv_bias=False,
                    qk_scale=None,
                    drop=0.,
                    attn_drop=0.,
                    drop_paths=None,
                    act_layer=nn.GELU,
                    norm_layer=nn.LayerNorm,
                    depth=2,
                    use_chk=False,
                    resi_connection='1conv',
                    rg_idx=0):
        super().__init__()
        self.use_chk = use_chk  # 是否使用梯度检查点以节省内存
        self.reso = reso  # 输入分辨率

        # 创建多个DATB（Dual Aggregation Transformer Block）
        # 每个block根据索引交替使用空间和通道注意力
        self.blocks = nn.ModuleList([
        DATB(
            dim=dim,  # 特征维度
            num_heads=num_heads,  # 注意力头数
            reso = reso,  # 分辨率
            split_size = split_size,  # 窗口分割尺寸
            shift_size = [split_size[0]//2, split_size[1]//2],  # shift尺寸为分割尺寸的一半
            expansion_factor=expansion_factor,  # FFN扩展因子
            qkv_bias=qkv_bias,  # QKV的偏置
            qk_scale=qk_scale,  # QK的缩放因子
            drop=drop,  # Dropout比率
            attn_drop=attn_drop,  # 注意力Dropout比率
            drop_path=drop_paths[i],  # 每个block的DropPath比率（可能不同）
            act_layer=act_layer,  # 激活函数类型
            norm_layer=norm_layer,  # 归一化层类型
            rg_idx = rg_idx,  # ResidualGroup的索引
            b_idx = i,  # Block的索引（用于决定使用哪种注意力）
            )for i in range(depth)])  # 创建depth个block

        # 残差连接前的卷积块：用于特征融合和维度调整
        if resi_connection == '1conv':
            # 使用单个3×3卷积
            self.conv = nn.Conv2d(dim, dim, 3, 1, 1)  # 3×3卷积，保持维度不变
        elif resi_connection == '3conv':
            # 使用三个卷积层（降维-1×1-升维），节省参数
            self.conv = nn.Sequential(
                nn.Conv2d(dim, dim // 4, 3, 1, 1), nn.LeakyReLU(negative_slope=0.2, inplace=True),  # 降维
                nn.Conv2d(dim // 4, dim // 4, 1, 1, 0), nn.LeakyReLU(negative_slope=0.2, inplace=True),  # 1×1卷积
                nn.Conv2d(dim // 4, dim, 3, 1, 1))  # 升维

    def forward(self, x, x_size):
        """
        前向传播
        
        Input: 
            x: 输入张量，形状为 (B, H*W, C)
            x_size: 图像尺寸元组 (H, W)
        
        Output: 
            x: 输出张量，形状为 (B, H*W, C)
        """
        H, W = x_size  # 解包图像高度和宽度
        res = x  # 保存输入作为残差连接的起点
        # 依次通过所有DATB block
        for blk in self.blocks:
            if self.use_chk:
                # 使用梯度检查点：在前向传播时不保存中间激活值，只在反向传播时重新计算
                # 这样可以节省显存，但会增加计算时间
                x = checkpoint.checkpoint(blk, x, x_size)
            else:
                # 正常前向传播
                x = blk(x, x_size)
        # 将序列格式转换为空间格式：(B, H*W, C) -> (B, C, H, W)
        x = rearrange(x, "b (h w) c -> b c h w", h=H, w=W).contiguous()
        # 通过残差连接前的卷积块
        x = self.conv(x)  # (B, C, H, W)
        # 转换回序列格式：(B, C, H, W) -> (B, H*W, C)
        x = rearrange(x, "b c h w -> b (h w) c")
        # 残差连接：与输入相加
        x = res + x  # (B, H*W, C)

        return x  # 返回处理后的特征


class Upsample(nn.Sequential):
    """Upsample module.
    Args:
        scale (int): Scale factor. Supported scales: 2^n and 3.
        num_feat (int): Channel number of intermediate features.
    """
    def __init__(self, scale, num_feat):
        m = []  # 存储上采样模块的列表
        # 检查scale是否为2的幂次（2^n），使用位运算：scale & (scale - 1) == 0
        if (scale & (scale - 1)) == 0:  # scale = 2^n（如2, 4, 8, 16等）
            # 对于2的幂次，需要log2(scale)次2倍上采样
            # 例如：scale=4需要2次2倍上采样，scale=8需要3次
            for _ in range(int(math.log(scale, 2))):
                # 每次上采样：先卷积扩展通道，再PixelShuffle缩小通道并放大空间
                m.append(nn.Conv2d(num_feat, 4 * num_feat, 3, 1, 1))  # 将通道数扩展4倍
                m.append(nn.PixelShuffle(2))  # PixelShuffle：将4个通道重组为2×2的空间，实现2倍上采样
        elif scale == 3:
            # 对于scale=3，只需要一次3倍上采样
            m.append(nn.Conv2d(num_feat, 9 * num_feat, 3, 1, 1))  # 将通道数扩展9倍
            m.append(nn.PixelShuffle(3))  # PixelShuffle：将9个通道重组为3×3的空间，实现3倍上采样
        else:
            # 不支持其他缩放因子
            raise ValueError(f'scale {scale} is not supported. ' 'Supported scales: 2^n and 3.')
        super(Upsample, self).__init__(*m)  # 将模块列表传递给Sequential父类


class UpsampleOneStep(nn.Sequential):
    """UpsampleOneStep module (the difference with Upsample is that it always only has 1conv + 1pixelshuffle)
       Used in lightweight SR to save parameters.

    Args:
        scale (int): Scale factor. Supported scales: 2^n and 3.
        num_feat (int): Channel number of intermediate features.

    """

    def __init__(self, scale, num_feat, num_out_ch, input_resolution=None):
        self.num_feat = num_feat  # 输入特征通道数
        self.input_resolution = input_resolution  # 输入分辨率，用于计算FLOPs
        m = []  # 存储上采样模块的列表
        # 一步上采样：直接将特征通道扩展为scale^2倍输出通道，然后PixelShuffle
        # 相比Upsample类，这里只进行一次上采样操作，节省参数
        m.append(nn.Conv2d(num_feat, (scale**2) * num_out_ch, 3, 1, 1))  # 卷积：扩展到scale^2倍输出通道
        m.append(nn.PixelShuffle(scale))  # PixelShuffle：实现scale倍上采样并恢复输出通道数
        super(UpsampleOneStep, self).__init__(*m)  # 将模块列表传递给Sequential父类

    def flops(self):
        """
        计算FLOPs（浮点运算次数）
        
        Returns:
            flops: 浮点运算次数
        """
        h, w = self.input_resolution  # 获取输入图像的高度和宽度
        # FLOPs = 输出像素数 × 输入通道数 × 卷积核大小（3×3=9）
        # 这里只计算卷积层的FLOPs，PixelShuffle只是重排操作，计算量可忽略
        flops = h * w * self.num_feat * 3 * 9  # 3×3卷积核的FLOPs
        return flops  # 返回FLOPs值


@ARCH_REGISTRY.register()
class DAT(nn.Module):
    """ 
    双聚合Transformer (Dual Aggregation Transformer)
    
    Args:
        img_size (int): 输入图像尺寸，默认为64
        in_chans (int): 输入图像通道数，默认为3
        embed_dim (int): 补丁嵌入维度，默认为180
        depths (tuple(int)): 每个残差组的深度（每个RG中DATB的数量）
        split_size (tuple(int)): 空间窗口的高度和宽度
        num_heads (tuple(int)): 不同残差组中的注意力头数
        expansion_factor (float): FFN隐藏维度与嵌入维度的比率，默认为4
        qkv_bias (bool): 如果为True，为query、key、value添加可学习偏置，默认为True
        qk_scale (float | None): 如果设置，覆盖默认的qk缩放因子 head_dim ** -0.5，默认为None
        drop_rate (float): Dropout比率，默认为0
        attn_drop_rate (float): 注意力Dropout比率，默认为0
        drop_path_rate (float): 随机深度比率，默认为0.1
        act_layer (nn.Module): 激活函数层，默认为nn.GELU
        norm_layer (nn.Module): 归一化层，默认为nn.LayerNorm
        use_chk (bool): 是否使用检查点以节省内存
        upscale: 上采样因子，2/3/4用于图像超分辨率
        img_range: 图像范围，1.或255.
        resi_connection: 残差连接前的卷积块，'1conv'/'3conv'
    """
    def __init__(self,
                img_size=64,
                in_chans=3,
                embed_dim=180,
                split_size=[2,4],
                depth=[2,2,2,2],
                num_heads=[2,2,2,2],
                expansion_factor=4.,
                qkv_bias=True,
                qk_scale=None,
                drop_rate=0.,
                attn_drop_rate=0.,
                drop_path_rate=0.1,
                act_layer=nn.GELU,
                norm_layer=nn.LayerNorm,
                use_chk=False,
                upscale=2,
                img_range=1.,
                resi_connection='1conv',
                upsampler='pixelshuffle',
                **kwargs):
        super().__init__()

        # 基本参数设置
        num_in_ch = in_chans  # 输入通道数
        num_out_ch = in_chans  # 输出通道数
        num_feat = 64  # 特征通道数
        self.img_range = img_range  # 图像范围
        
        # 设置图像均值（用于归一化）
        if in_chans == 3:
            rgb_mean = (0.4488, 0.4371, 0.4040)  # RGB图像的均值
            self.mean = torch.Tensor(rgb_mean).view(1, 3, 1, 1)
        else:
            self.mean = torch.zeros(1, 1, 1, 1)  # 灰度图像的均值
        self.upscale = upscale  # 上采样因子
        self.upsampler = upsampler  # 上采样器类型

        # ------------------------- 1, 浅层特征提取 ------------------------- #
        self.conv_first = nn.Conv2d(num_in_ch, embed_dim, 3, 1, 1)  # 第一个卷积层

        # ------------------------- 2, Deep Feature Extraction ------------------------- #
        self.num_layers = len(depth)  # ResidualGroup的数量，等于depth列表的长度
        self.use_chk = use_chk  # 是否使用梯度检查点
        self.num_features = self.embed_dim = embed_dim  # 特征维度，用于与其他模型保持一致

        # 在进入ResidualGroup之前：将空间格式转换为序列格式，并进行层归一化
        self.before_RG = nn.Sequential(
            Rearrange('b c h w -> b (h w) c'),  # 将(B, C, H, W)转换为(B, H*W, C)的序列格式
            nn.LayerNorm(embed_dim)  # 层归一化，稳定训练
        )

        curr_dim = embed_dim  # 当前特征维度（保持embed_dim不变）
        # 随机深度衰减规则：为每个block生成不同的drop_path_rate
        # 从0线性增加到drop_path_rate，总共有sum(depth)个block
        dpr = [x.item() for x in torch.linspace(0, drop_path_rate, np.sum(depth))]

        # 创建多个ResidualGroup（残差组）
        self.layers = nn.ModuleList()
        for i in range(self.num_layers):
            layer = ResidualGroup(
                dim=embed_dim,  # 特征维度
                num_heads=heads[i],  # 第i个组的注意力头数
                reso=img_size,  # 图像分辨率
                split_size=split_size,  # 窗口分割尺寸
                expansion_factor=expansion_factor,  # FFN扩展因子
                qkv_bias=qkv_bias,  # QKV偏置
                qk_scale=qk_scale,  # QK缩放因子
                drop=drop_rate,  # Dropout比率
                attn_drop=attn_drop_rate,  # 注意力Dropout比率
                # 为当前组的所有block分配drop_path_rate
                # sum(depth[:i])是前面所有组的block总数，sum(depth[:i+1])是包括当前组的block总数
                drop_paths=dpr[sum(depth[:i]):sum(depth[:i + 1])],
                act_layer=act_layer,  # 激活函数类型
                norm_layer=norm_layer,  # 归一化层类型
                depth=depth[i],  # 当前组的block数量
                use_chk=use_chk,  # 是否使用检查点
                resi_connection=resi_connection,  # 残差连接类型
                rg_idx=i)  # ResidualGroup的索引
            self.layers.append(layer)  # 添加到层列表

        self.norm = norm_layer(curr_dim)  # 最后一个归一化层
        # 构建深层特征提取后的卷积层
        if resi_connection == '1conv':
            # 使用单个3×3卷积
            self.conv_after_body = nn.Conv2d(embed_dim, embed_dim, 3, 1, 1)
        elif resi_connection == '3conv':
            # 使用三个卷积层（降维-1×1-升维），节省参数和内存
            self.conv_after_body = nn.Sequential(
                nn.Conv2d(embed_dim, embed_dim // 4, 3, 1, 1), nn.LeakyReLU(negative_slope=0.2, inplace=True),  # 降维
                nn.Conv2d(embed_dim // 4, embed_dim // 4, 1, 1, 0), nn.LeakyReLU(negative_slope=0.2, inplace=True),  # 1×1卷积
                nn.Conv2d(embed_dim // 4, embed_dim, 3, 1, 1))  # 升维

        # ------------------------- 3, Reconstruction ------------------------- #
        if self.upsampler == 'pixelshuffle':
            # 用于经典超分辨率：先降维，再上采样，最后输出
            self.conv_before_upsample = nn.Sequential(
                nn.Conv2d(embed_dim, num_feat, 3, 1, 1), nn.LeakyReLU(inplace=True))  # 降维到num_feat
            self.upsample = Upsample(upscale, num_feat)  # 上采样模块
            self.conv_last = nn.Conv2d(num_feat, num_out_ch, 3, 1, 1)  # 最终输出层
        elif self.upsampler == 'pixelshuffledirect':
            # 用于轻量级超分辨率：直接上采样，节省参数
            self.upsample = UpsampleOneStep(upscale, embed_dim, num_out_ch,
                                            (img_size, img_size))

        # 初始化模型权重
        self.apply(self._init_weights)

    def _init_weights(self, m):
        """
        权重初始化函数
        
        Args:
            m: 模型模块
        """
        if isinstance(m, nn.Linear):
            # 线性层：使用截断正态分布初始化权重
            trunc_normal_(m.weight, std=.02)  # 标准差为0.02
            # 如果有偏置，初始化为0
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, (nn.LayerNorm, nn.BatchNorm2d, nn.GroupNorm, nn.InstanceNorm2d)):
            # 归一化层：偏置初始化为0，权重初始化为1
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    def forward_features(self, x):
        """
        深层特征提取的前向传播
        
        Args:
            x: 输入张量，形状为 (B, C, H, W)
        
        Returns:
            x: 提取的特征，形状为 (B, C, H, W)
        """
        _, _, H, W = x.shape  # 获取图像的高度和宽度
        x_size = [H, W]  # 图像尺寸列表
        # 转换为序列格式并归一化：(B, C, H, W) -> (B, H*W, C)
        x = self.before_RG(x)
        # 依次通过所有ResidualGroup
        for layer in self.layers:
            x = layer(x, x_size)  # (B, H*W, C)
        # 最终归一化
        x = self.norm(x)
        # 转换回空间格式：(B, H*W, C) -> (B, C, H, W)
        x = rearrange(x, "b (h w) c -> b c h w", h=H, w=W).contiguous()

        return x  # 返回提取的特征

    def forward(self, x):
        """
        前向传播
        
        Args:
            x: 输入张量，形状为 (B, C, H, W)
        
        Returns:
            输出张量，形状为 (B, C, H*upscale, W*upscale)
        """
        # 将均值张量移动到与输入相同的设备上
        self.mean = self.mean.type_as(x)
        # 图像归一化：减去均值并缩放到指定范围
        x = (x - self.mean) * self.img_range

        if self.upsampler == 'pixelshuffle':
            # 用于经典图像超分辨率
            x = self.conv_first(x)  # 浅层特征提取：(B, C, H, W) -> (B, embed_dim, H, W)
            # 深层特征提取 + 残差连接
            # forward_features: (B, embed_dim, H, W) -> (B, embed_dim, H, W)
            # conv_after_body: 特征融合
            # 最后与浅层特征相加，实现全局残差连接
            x = self.conv_after_body(self.forward_features(x)) + x  # (B, embed_dim, H, W)
            x = self.conv_before_upsample(x)  # 上采样前的卷积：降维到num_feat
            x = self.conv_last(self.upsample(x))  # 上采样 + 最终卷积：输出超分辨率图像
        elif self.upsampler == 'pixelshuffledirect':
            # 用于轻量级超分辨率（节省参数）
            x = self.conv_first(x)  # 浅层特征提取
            # 深层特征提取 + 残差连接
            x = self.conv_after_body(self.forward_features(x)) + x
            x = self.upsample(x)  # 直接上采样（一步完成，包含输出通道转换）

        # 反归一化：恢复到原始图像范围
        # 先除以img_range，再加上均值，恢复原始的像素值范围
        x = x / self.img_range + self.mean
        return x  # 返回超分辨率图像 (B, C, H*upscale, W*upscale)


if __name__ == '__main__':
    """
    即插即用模块的最小化形状测试
    测试各个模块是否能保持输入输出形状一致
    """
    # 设备选择：优先使用GPU，否则使用CPU
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    # 测试参数：批次大小、图像高度、宽度
    B, H, W = 1, 32, 32
    dim, heads = 64, 8  # 特征维度、注意力头数
    N = H * W  # 总像素数（序列长度）

    # token 形式输入: (B, H*W, C)，这是Transformer的标准输入格式
    x_tokens = torch.randn(B, N, dim, device=device)

    # 1) 测试DSTB: Adaptive_Spatial_Attention（自适应空间注意力）
    dstb = Adaptive_Spatial_Attention(
        dim=dim,  # 特征维度
        num_heads=heads,  # 注意力头数
        reso=H,  # 分辨率
        split_size=[8, 8],  # 窗口分割尺寸（8×8）
        shift_size=[1, 2],  # 窗口平移尺寸
        qkv_bias=True,  # QKV偏置
        qk_scale=None,  # QK缩放因子（使用默认值）
        drop=0.0,  # Dropout比率
        attn_drop=0.0,  # 注意力Dropout比率
        rg_idx=0,  # ResidualGroup索引
        b_idx=0,  # Block索引（偶数，使用空间注意力）
    ).to(device).eval()  # 移动到指定设备并设置为评估模式
    with torch.no_grad():  # 禁用梯度计算，节省内存
        y_dstb = dstb(x_tokens, H, W)  # 前向传播
    print(f"DSTB in/out: {tuple(x_tokens.shape)} -> {tuple(y_dstb.shape)}")
    assert y_dstb.shape == x_tokens.shape  # 断言：确保输入输出形状一致

    # 2) 测试DCTB: Adaptive_Channel_Attention（自适应通道注意力）
    dctb = Adaptive_Channel_Attention(
        dim=dim,  # 特征维度
        num_heads=heads,  # 注意力头数
        qkv_bias=True,  # QKV偏置
        qk_scale=None,  # QK缩放因子
        attn_drop=0.0,  # 注意力Dropout比率
        proj_drop=0.0,  # 投影Dropout比率
    ).to(device).eval()
    with torch.no_grad():
        y_dctb = dctb(x_tokens, H, W)  # 前向传播
    print(f"DCTB in/out: {tuple(x_tokens.shape)} -> {tuple(y_dctb.shape)}")
    assert y_dctb.shape == x_tokens.shape  # 断言：确保输入输出形状一致

    # 3) 测试DATB: b_idx=0（偶数索引，使用DSTB分支）
    datb_even = DATB(
        dim=dim,  # 特征维度
        num_heads=heads,  # 注意力头数
        reso=H,  # 分辨率
        split_size=[8, 8],  # 窗口分割尺寸
        shift_size=[1, 2],  # 窗口平移尺寸
        expansion_factor=4.0,  # FFN扩展因子
        qkv_bias=True,  # QKV偏置
        qk_scale=None,  # QK缩放因子
        drop=0.0,  # Dropout比率
        attn_drop=0.0,  # 注意力Dropout比率
        drop_path=0.0,  # DropPath比率
        rg_idx=0,  # ResidualGroup索引
        b_idx=0,  # Block索引（偶数，使用空间注意力）
    ).to(device).eval()
    with torch.no_grad():
        y_datb_even = datb_even(x_tokens, (H, W))  # 前向传播，注意这里传入的是元组
    print(f"DATB(even) in/out: {tuple(x_tokens.shape)} -> {tuple(y_datb_even.shape)}")
    assert y_datb_even.shape == x_tokens.shape  # 断言：确保输入输出形状一致

    # 4) 测试DATB: b_idx=1（奇数索引，使用DCTB分支）
    datb_odd = DATB(
        dim=dim,  # 特征维度
        num_heads=heads,  # 注意力头数
        reso=H,  # 分辨率
        split_size=[8, 8],  # 窗口分割尺寸
        shift_size=[1, 2],  # 窗口平移尺寸
        expansion_factor=4.0,  # FFN扩展因子
        qkv_bias=True,  # QKV偏置
        qk_scale=None,  # QK缩放因子
        drop=0.0,  # Dropout比率
        attn_drop=0.0,  # 注意力Dropout比率
        drop_path=0.0,  # DropPath比率
        rg_idx=0,  # ResidualGroup索引
        b_idx=1,  # Block索引（奇数，使用通道注意力）
    ).to(device).eval()
    with torch.no_grad():
        y_datb_odd = datb_odd(x_tokens, (H, W))  # 前向传播
    print(f"DATB(odd) in/out: {tuple(x_tokens.shape)} -> {tuple(y_datb_odd.shape)}")
    assert y_datb_odd.shape == x_tokens.shape  # 断言：确保输入输出形状一致

    print('All plug-and-play module shape tests passed.')  # 所有测试通过