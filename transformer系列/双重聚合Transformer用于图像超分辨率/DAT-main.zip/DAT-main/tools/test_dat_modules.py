"""
即插即用模块测试脚本
测试 Adaptive_Channel_Attention、Adaptive_Spatial_Attention 和 SGFN 模块
确保这些模块可以即插即用，输入输出形状保持一致
"""

import torch
import torch.nn as nn
import sys
import os

# 添加项目路径到sys.path，以便导入basicsr模块
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from basicsr.archs.dat_arch import (
    Adaptive_Channel_Attention,
    Adaptive_Spatial_Attention,
    SGFN
)


def test_sgfn():
    """
    测试 SGFN (Spatial-Gate Feed-Forward Network) 模块
    
    测试要点：
    1. 输入输出形状是否一致
    2. 模块是否能正常前向传播
    3. 梯度是否能正常反向传播
    """
    print("=" * 60)
    print("测试 SGFN (Spatial-Gate Feed-Forward Network)")
    print("=" * 60)
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"使用设备: {device}")
    
    # 测试参数设置
    B, H, W = 2, 32, 32  # 批次大小、图像高度、宽度
    dim = 64  # 特征维度
    N = H * W  # 序列长度（总像素数）
    hidden_features = 256  # 隐藏层维度
    
    # 创建测试输入：序列格式 (B, H*W, C)
    x_input = torch.randn(B, N, dim, device=device)
    print(f"输入形状: {x_input.shape}")
    
    # 创建 SGFN 模块
    sgfn = SGFN(
        in_features=dim,
        hidden_features=hidden_features,
        out_features=dim,
        act_layer=nn.GELU,
        drop=0.1
    ).to(device)
    
    # 设置为评估模式
    sgfn.eval()
    
    # 前向传播测试
    with torch.no_grad():
        x_output = sgfn(x_input, H, W)
    
    print(f"输出形状: {x_output.shape}")
    
    # 验证输入输出形状是否一致
    assert x_output.shape == x_input.shape, \
        f"形状不匹配！输入: {x_input.shape}, 输出: {x_output.shape}"
    print("✓ 输入输出形状一致")
    
    # 梯度测试（训练模式）
    sgfn.train()
    x_input.requires_grad_(True)
    x_output = sgfn(x_input, H, W)
    loss = x_output.sum()
    loss.backward()
    
    assert x_input.grad is not None, "梯度未正确计算"
    print("✓ 梯度反向传播正常")
    
    print("SGFN 测试通过！\n")
    return True


def test_adaptive_channel_attention():
    """
    测试 Adaptive_Channel_Attention 模块
    
    测试要点：
    1. 输入输出形状是否一致
    2. 模块是否能正常前向传播
    3. 梯度是否能正常反向传播
    """
    print("=" * 60)
    print("测试 Adaptive_Channel_Attention")
    print("=" * 60)
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"使用设备: {device}")
    
    # 测试参数设置
    B, H, W = 2, 32, 32  # 批次大小、图像高度、宽度
    dim = 64  # 特征维度
    num_heads = 8  # 注意力头数
    N = H * W  # 序列长度（总像素数）
    
    # 创建测试输入：序列格式 (B, H*W, C)
    x_input = torch.randn(B, N, dim, device=device)
    print(f"输入形状: {x_input.shape}")
    
    # 创建 Adaptive_Channel_Attention 模块
    channel_attn = Adaptive_Channel_Attention(
        dim=dim,
        num_heads=num_heads,
        qkv_bias=True,
        qk_scale=None,
        attn_drop=0.1,
        proj_drop=0.1
    ).to(device)
    
    # 设置为评估模式
    channel_attn.eval()
    
    # 前向传播测试
    with torch.no_grad():
        x_output = channel_attn(x_input, H, W)
    
    print(f"输出形状: {x_output.shape}")
    
    # 验证输入输出形状是否一致
    assert x_output.shape == x_input.shape, \
        f"形状不匹配！输入: {x_input.shape}, 输出: {x_output.shape}"
    print("✓ 输入输出形状一致")
    
    # 梯度测试（训练模式）
    channel_attn.train()
    x_input.requires_grad_(True)
    x_output = channel_attn(x_input, H, W)
    loss = x_output.sum()
    loss.backward()
    
    assert x_input.grad is not None, "梯度未正确计算"
    print("✓ 梯度反向传播正常")
    
    print("Adaptive_Channel_Attention 测试通过！\n")
    return True


def test_adaptive_spatial_attention():
    """
    测试 Adaptive_Spatial_Attention 模块
    
    测试要点：
    1. 输入输出形状是否一致
    2. 模块是否能正常前向传播
    3. 梯度是否能正常反向传播
    4. 测试不同配置参数
    """
    print("=" * 60)
    print("测试 Adaptive_Spatial_Attention")
    print("=" * 60)
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"使用设备: {device}")
    
    # 测试参数设置
    B, H, W = 2, 32, 32  # 批次大小、图像高度、宽度
    dim = 64  # 特征维度
    num_heads = 8  # 注意力头数
    N = H * W  # 序列长度（总像素数）
    
    # 创建测试输入：序列格式 (B, H*W, C)
    x_input = torch.randn(B, N, dim, device=device)
    print(f"输入形状: {x_input.shape}")
    
    # 测试配置1：基本配置（不使用shift window）
    print("\n--- 测试配置1: 基本配置 (b_idx=0, rg_idx=0) ---")
    spatial_attn_1 = Adaptive_Spatial_Attention(
        dim=dim,
        num_heads=num_heads,
        reso=H,
        split_size=[8, 8],  # 8×8窗口
        shift_size=[1, 2],
        qkv_bias=True,
        qk_scale=None,
        drop=0.1,
        attn_drop=0.1,
        rg_idx=0,
        b_idx=0  # 偶数索引，不使用shift window
    ).to(device)
    
    spatial_attn_1.eval()
    with torch.no_grad():
        x_output_1 = spatial_attn_1(x_input, H, W)
    
    print(f"输出形状: {x_output_1.shape}")
    assert x_output_1.shape == x_input.shape, \
        f"形状不匹配！输入: {x_input.shape}, 输出: {x_output_1.shape}"
    print("✓ 配置1测试通过：输入输出形状一致")
    
    # 测试配置2：使用shift window (需要掩码)
    print("\n--- 测试配置2: Shift Window (b_idx=2, rg_idx=0) ---")
    spatial_attn_2 = Adaptive_Spatial_Attention(
        dim=dim,
        num_heads=num_heads,
        reso=H,
        split_size=[8, 8],
        shift_size=[1, 2],
        qkv_bias=True,
        qk_scale=None,
        drop=0.1,
        attn_drop=0.1,
        rg_idx=0,
        b_idx=2  # 满足 (b_idx - 2) % 4 == 0，使用shift window
    ).to(device)
    
    spatial_attn_2.eval()
    with torch.no_grad():
        x_output_2 = spatial_attn_2(x_input, H, W)
    
    print(f"输出形状: {x_output_2.shape}")
    assert x_output_2.shape == x_input.shape, \
        f"形状不匹配！输入: {x_input.shape}, 输出: {x_output_2.shape}"
    print("✓ 配置2测试通过：输入输出形状一致")
    
    # 测试配置3：不同的窗口尺寸
    print("\n--- 测试配置3: 不同窗口尺寸 (split_size=[4, 8]) ---")
    spatial_attn_3 = Adaptive_Spatial_Attention(
        dim=dim,
        num_heads=num_heads,
        reso=H,
        split_size=[4, 8],  # 矩形窗口 4×8
        shift_size=[1, 2],
        qkv_bias=True,
        qk_scale=None,
        drop=0.1,
        attn_drop=0.1,
        rg_idx=0,
        b_idx=0
    ).to(device)
    
    spatial_attn_3.eval()
    with torch.no_grad():
        x_output_3 = spatial_attn_3(x_input, H, W)
    
    print(f"输出形状: {x_output_3.shape}")
    assert x_output_3.shape == x_input.shape, \
        f"形状不匹配！输入: {x_input.shape}, 输出: {x_output_3.shape}"
    print("✓ 配置3测试通过：输入输出形状一致")
    
    # 梯度测试
    print("\n--- 梯度反向传播测试 ---")
    spatial_attn_1.train()
    x_input.requires_grad_(True)
    x_output = spatial_attn_1(x_input, H, W)
    loss = x_output.sum()
    loss.backward()
    
    assert x_input.grad is not None, "梯度未正确计算"
    print("✓ 梯度反向传播正常")
    
    print("\nAdaptive_Spatial_Attention 所有测试通过！\n")
    return True


def test_all_modules_together():
    """
    测试所有模块串联使用（即插即用的典型场景）
    """
    print("=" * 60)
    print("测试模块串联使用（即插即用场景）")
    print("=" * 60)
    
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"使用设备: {device}")
    
    # 测试参数设置
    B, H, W = 2, 32, 32
    dim = 64
    num_heads = 8
    N = H * W
    
    # 创建测试输入
    x = torch.randn(B, N, dim, device=device)
    print(f"初始输入形状: {x.shape}")
    
    # 创建模块
    sgfn = SGFN(dim, hidden_features=256, out_features=dim).to(device)
    channel_attn = Adaptive_Channel_Attention(dim, num_heads=num_heads).to(device)
    spatial_attn = Adaptive_Spatial_Attention(
        dim, num_heads=num_heads, reso=H, split_size=[8, 8], 
        shift_size=[1, 2], rg_idx=0, b_idx=0
    ).to(device)
    
    # 串联测试：SGFN -> Channel Attention -> Spatial Attention
    print("\n串联顺序: SGFN -> Channel Attention -> Spatial Attention")
    
    with torch.no_grad():
        x = sgfn(x, H, W)
        print(f"经过 SGFN 后形状: {x.shape}")
        assert x.shape == (B, N, dim), "SGFN输出形状错误"
        
        x = channel_attn(x, H, W)
        print(f"经过 Channel Attention 后形状: {x.shape}")
        assert x.shape == (B, N, dim), "Channel Attention输出形状错误"
        
        x = spatial_attn(x, H, W)
        print(f"经过 Spatial Attention 后形状: {x.shape}")
        assert x.shape == (B, N, dim), "Spatial Attention输出形状错误"
    
    print("✓ 所有模块串联使用正常，输入输出形状保持一致\n")
    return True


def main():
    """
    主测试函数
    """
    print("\n" + "=" * 60)
    print("DAT 即插即用模块测试")
    print("=" * 60 + "\n")
    
    try:
        # 测试各个模块
        test_sgfn()
        test_adaptive_channel_attention()
        test_adaptive_spatial_attention()
        test_all_modules_together()
        
        print("=" * 60)
        print("所有测试通过！✓")
        print("=" * 60)
        print("\n测试总结：")
        print("1. SGFN: 输入输出形状一致 ✓")
        print("2. Adaptive_Channel_Attention: 输入输出形状一致 ✓")
        print("3. Adaptive_Spatial_Attention: 输入输出形状一致 ✓")
        print("4. 模块串联使用: 正常工作 ✓")
        print("\n所有模块都可以作为即插即用模块使用！")
        
    except AssertionError as e:
        print(f"\n❌ 测试失败: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ 发生错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
